#NC COVID Community Resources
#Built using flexdashboard + shiny

#Required packages: 
# - markdown
# - flexdashboard
# - tidyverse
# - shiny
# - leaflet
# - googlesheets4
# - DT


rmarkdown::draft("dashboard.Rmd", template = "flex_dashboard", package = "flexdashboard")
